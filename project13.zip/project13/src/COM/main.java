package COM;

 public class main{
    int data;
    main next;
 
    main(int data, main next)
    {
        this.data = data;
        this.next = next;
    }
}
 
class Main
{
    public static main findKthNode(main head, int k)
    {
        int n = 0;
        main curr = head;
 
        while (curr != null)
        {
            curr = curr.next;
            n++;
        }
        if (n >= k)
        {
        
            curr = head;
            for (int i = 0; i < n - k; i++) {
                curr = curr.next;
            }
        }
 
        return curr;
    }
 
    public static void main(String[] args)
    {
 
        int[] keys = { 1, 2, 3, 4, 5 };
 
        main head = null;
        for (int i = keys.length - 1; i >= 0; i--) {
            head = new main(keys[i], head);
        }
 
        int k = 3;
        main node = findKthNode(head, k);
 
        if (node != null) {
            System.out.println("k'th node from the end is " + node.data);
        }
    }
}