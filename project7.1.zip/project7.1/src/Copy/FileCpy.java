package Copy;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCpy {

    public static void main(String[] args) throws IOException {

        var source = new File("F:/video/CSSNotesForProfessionals");
        var dest = new File("F:/video/CSSNotesForProfessionals");

        try (var fis = new FileInputStream(source);
             var fos = new FileOutputStream(dest)) {

            byte[] buffer = new byte[1024];
            int length;

            while ((length = fis.read(buffer)) > 0) {

                fos.write(buffer, 0, length);
            }
        }
    }
}