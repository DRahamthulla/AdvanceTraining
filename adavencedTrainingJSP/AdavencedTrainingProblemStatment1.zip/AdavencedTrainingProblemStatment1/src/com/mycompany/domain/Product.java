package com.mycompany.domain;

public class Product {
		 int ProductID;
		 String ProductName;
	     float Productprice ;
		public int getProductID() {
			return ProductID;
		}
		public void setProductID(int productID) {
			ProductID = productID;
		}
		public String getProductName() {
			return ProductName;
		}
		public void setProductName(String productName) {
			ProductName = productName;
		}
		public float getProductprice() {
			return Productprice;
		}
		public void setProductprice(float productprice) {
			Productprice = productprice;
		}
	     
}