package com;

public class SortedArray {
	
	static void dupilate(int arr[],int n) {
		
		int elt=1;
		
		for(int i=1;i<n;i++) {
			
			if(arr[i]==arr[i-1]) {
				elt++;
			}
			else {
				System.out.println("elements ocuur of " +arr[i-1]+ " is " +elt);
				elt=1;
			}
		}
		System.out.println("elements ocuur of " +arr[n-1]+ " is " +elt);
	}
	public static void main(String args[]) {
		int arr[]={2, 2, 2, 4, 4, 4, 5, 5, 6, 8, 8, 9};
		int n=arr.length;
		dupilate(arr, n);
	}

}
