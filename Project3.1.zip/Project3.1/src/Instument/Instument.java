package Instument;


	public abstract class Instument 
	{
	    public abstract void Play();
	}

	     class Piano extends Instument
	{
	      public void Play()
	{
	      System.out.println("Piano is playing tan tan tan tan");
	}
	}
	      class Flute extends Instument
	{
	      public void Play()
	{
	      System.out.println("Flute is playing toot toot toot toot");
	}
	}
	      class Guitar extends Instument
	{
	      public void Play()
	{
	       System.out.println("Guitar is playing tin tin tin ");
	}
	}
