package Rectangle;

public class RectangleProject {
	

	double length, width;
 
    RectangleProject()
    {
        length = 1;
        width = 1;
    }

    RectangleProject(double length, double width)
    {
        this.length = length;
        this.width  = width;
    }
   
    double getArea()
    {
        return (length * width);
    }
   
   

    public static void main(String[] args) {
        RectangleProject rect1 = new RectangleProject();
        RectangleProject rect2= new RectangleProject(15.0,8.0);
        RectangleProject rect3= new RectangleProject(1,9);
        RectangleProject rect4= new RectangleProject(5.5,8.8);
        RectangleProject rect5= new RectangleProject(15.0,8.0);


        
        System.out.println("Area of first object="+rect1.getArea());
        System.out.println("Area of second object="+rect2.getArea());
        System.out.println("Area of second object="+rect3.getArea());
        System.out.println("Area of second object="+rect4.getArea());
        System.out.println("Area of second object="+rect5.getArea());


   }
    
}